Fix the two bugs in word_wrap() inside wrap.cpp, then:

    make run

When the output has exactly 5 lines, read the first letter of
each line in order.  Those five letters are the word to type
into launch.py.

See the top-level README.md for the full walk-through.
