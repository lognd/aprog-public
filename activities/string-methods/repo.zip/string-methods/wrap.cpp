// wrap.cpp  --  the word_wrap function has bugs; find and fix them
//
//    make run          compile and run to see the output
//    (edit this file)
//    make run          run again to check your fix

#include <iostream>
#include <string>
#include <vector>

static std::vector<std::string> split_words(const std::string& text) {
    std::vector<std::string> words;
    std::string word;
    for (char c : text) {
        if (c == ' ') {
            if (!word.empty()) {
                words.push_back(word);
                word.clear();
            }
        } else {
            word += c;
        }
    }
    if (!word.empty())
        words.push_back(word);
    return words;
}

static std::vector<std::string> word_wrap(const std::string& text, int width) {
    std::vector<std::string> words = split_words(text);
    std::vector<std::string> lines;
    std::string current;

    for (const std::string& word : words) {
        if (current.empty()) {
            current = word;
        } else if ((int)(current.size() + 1 + word.size()) < width) {
            current += " " + word;
        } else {
            lines.push_back(current);
            current = word;
        }
    }
    return lines;
}

int main() {
    const std::string text =
        "Strings carry their own length. Push_back and emplace_back append. Length() and size() both give count. Insert places content at any index. The find method returns npos or pos.";

    const int width = 36;

    std::vector<std::string> lines = word_wrap(text, width);

    std::cout << "Lines: " << lines.size() << "\n";
    for (const std::string& line : lines)
        std::cout << line << "\n";
    return 0;
}
