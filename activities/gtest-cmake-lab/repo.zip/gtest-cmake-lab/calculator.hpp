#pragma once

class Calculator {
public:
    int add(int a, int b) const;
    int multiply(int a, int b) const;
    // Returns a / b.  Throws std::invalid_argument if b == 0.
    int divide(int a, int b) const;
};
