#include <gtest/gtest.h>
#include "calculator.hpp"

// -- Provided tests (do not modify) --

TEST(CalculatorTest, AddPositive) {
    Calculator c;
    EXPECT_EQ(c.add(3, 4), 7);
}

TEST(CalculatorTest, MultiplyByZero) {
    Calculator c;
    EXPECT_EQ(c.multiply(5, 0), 0);
}

TEST(CalculatorTest, DivideByZeroThrows) {
    Calculator c;
    EXPECT_THROW(c.divide(10, 0), std::invalid_argument);
}

// -- TODO: write two new TEST cases below --
// Suggestion 1: test that add() works with negative numbers.
// Suggestion 2: test that divide() returns the correct integer quotient.
