// inventory.cpp -- a tiny inventory list with THREE separate memory leaks.
//
// Each item has a name (a heap-allocated C string) and a quantity.
// The program builds a small list of items, prints them, and cleans up.
//
// There are three distinct leaks hidden in this file. Find and fix all
// three, then rebuild and rerun under valgrind until it reports
// "definitely lost: 0 bytes".

#include <cstdio>
#include <cstring>

struct Item {
    char* name;
    int quantity;
    Item* next;
};

// LEAK 1: this function allocates a new C string with `new char[...]` for
// the item's name, but never gives the caller a way to free the OLD name
// if this item is renamed later.  (See rename_item below.)
char* make_name(const char* src) {
    char* copy = new char[std::strlen(src) + 1];
    std::strcpy(copy, src);
    return copy;
}

Item* make_item(const char* name, int qty) {
    Item* it = new Item;
    it->name = make_name(name);
    it->quantity = qty;
    it->next = nullptr;
    return it;
}

// LEAK 1 (continued): renaming an item allocates a brand new name string
// but does not delete[] the old one first.
void rename_item(Item* it, const char* new_name) {
    it->name = make_name(new_name);
}

Item* push_front(Item* head, Item* it) {
    it->next = head;
    return it;
}

// LEAK 2: frees each Item node but forgets to delete[] its `name` first
// (missing delete[]).
void free_list_incomplete(Item* head) {
    while (head) {
        Item* next = head->next;
        delete head;   // BUG: head->name is never delete[]-d
        head = next;
    }
}

// LEAK 3: an early-return leak path.  If `qty` is invalid, this function
// returns early WITHOUT freeing the Item it just allocated.
Item* make_validated_item(const char* name, int qty) {
    Item* it = make_item(name, qty);
    if (qty < 0) {
        std::printf("invalid quantity for %s, skipping\n", name);
        return nullptr;   // BUG: `it` is leaked here -- never freed
    }
    return it;
}

int main() {
    Item* head = nullptr;
    head = push_front(head, make_item("bolts", 100));
    head = push_front(head, make_item("nuts", 250));
    head = push_front(head, make_item("washers", 500));

    rename_item(head, "washers-metric");

    Item* bad = make_validated_item("gaskets", -5);
    (void)bad;

    for (Item* it = head; it; it = it->next) {
        std::printf("%-16s qty=%d\n", it->name, it->quantity);
    }

    free_list_incomplete(head);

    std::printf("inventory report complete\n");
    return 0;
}
