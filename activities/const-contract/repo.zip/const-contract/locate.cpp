#include <cstdio>

// BUG: the function's return type is char*, but it returns a pointer
// into a const char* input. This strips the const qualifier.
// FIX: change the return type to 'const char*'.
char* find_dot(const char* s) {
    while (*s && *s != '.') ++s;
    return *s == '.' ? s : nullptr;   // ERROR: cannot convert const char* to char*
}

int main() {
    const char* path = "notes.txt";
    const char* ext = find_dot(path);
    if (ext) printf("Extension starts at: %s\n", ext);
    return 0;
}
