#include <cstdio>

// BUG: parameter is char* but the caller passes a const char*.
// FIX: change 'char*' to 'const char*' in the parameter list.
void print_label(char* text) {
    printf("Label: %s\n", text);
}

int main() {
    const char* greeting = "const-contracts";
    print_label(greeting);
    return 0;
}
