#include <cstdio>

// BUG: 'char* const' means the pointer itself is const and cannot be
// incremented. The body tries to advance s through the string.
// FIX: change 'char* const' to 'char*' -- the data does not need to be
// const here, only the pointer was (incorrectly) marked const.
int count_spaces(char* const s) {
    int n = 0;
    while (*s) {
        if (*s == ' ') n++;
        s++;             // ERROR: increment of read-only variable 's'
    }
    printf("Spaces: %d\n", n);
    return n;
}

int main() {
    char sentence[] = "the cat sat";
    count_spaces(sentence);
    return 0;
}
