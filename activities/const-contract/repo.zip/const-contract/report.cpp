#include <cstdio>

// BUG 1: tag_of takes char* but describe passes a const char*.
// FIX: change 'char*' to 'const char*' in tag_of's parameter.
const char* tag_of(char* name) {
    if (name[0] == 'B' || name[0] == 'b') return "beta";
    if (name[0] == 'A' || name[0] == 'a') return "alpha";
    return "other";
}

// BUG 2: after fixing tag_of, the 'char* copy = name' line fails because
// name is const char* and char* cannot alias it.
// FIX: change 'char* copy' to 'const char* copy' (or call tag_of(name) directly).
void describe(const char* name) {
    char* copy = name;        // ERROR after fix: invalid conversion
    const char* tag = tag_of(copy);
    printf("%s -> %s\n", name, tag);
}

int main() {
    describe("Bravo");
    return 0;
}
