#include <cstdio>
#include <cstring>

// BUG: the function takes const char* (correct!) but then tries to
// modify the string through the pointer.
// FIX: copy s into a local char buffer before modifying it.
void redact(const char* s) {
    int len = (int)strlen(s);
    s[0] = '*';           // ERROR: assignment of read-only location
    s[len - 1] = '*';
    printf("Redacted: %s\n", s);
}

int main() {
    const char* secret = "secret";
    redact(secret);
    return 0;
}
