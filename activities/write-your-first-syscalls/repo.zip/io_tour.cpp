// io_tour.cpp
// Fill in the three marked sections below.
// This program should print the contents of argv[1] to the terminal.
//
// Permitted calls: open(), read(), write(), close(), perror()
// Headers already included: <fcntl.h>  <unistd.h>  <stdio.h>
//
// Compile and run:
//   make
//   ./io_tour sample.txt

#include <fcntl.h>   // open(), O_RDONLY
#include <unistd.h>  // read(), write(), close()
#include <stdio.h>   // perror()

// The three standard file descriptors every POSIX process starts with.
// We will cover what "stdin" and "stdout" are when we reach streams --
// for now, just know that writing to STDOUT_FD sends bytes to the terminal.
static constexpr int STDIN_FD  = 0;
static constexpr int STDOUT_FD = 1;
static constexpr int STDERR_FD = 2;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        write(STDERR_FD, "usage: io_tour <file>\n", 21);
        return 1;
    }

    // ------------------------------------------------------------------
    // FILL IN 1: Open argv[1] for reading.
    //   Signature: int open(const char *path, int flags);
    //   On success: returns the new fd (>= 0)
    //   On failure: returns -1 and sets errno
    //
    //   Replace the -1 below with a real open() call.
    // ------------------------------------------------------------------
    int fd = /* FILL IN */ -1;
    if (fd == -1) { perror("open"); return 1; }

    // ------------------------------------------------------------------
    // FILL IN 2: Read bytes from fd in a loop until EOF.
    //   Signature: ssize_t read(int fd, void *buf, size_t count);
    //   Returns: > 0  bytes read this call
    //              0  end-of-file
    //             -1  error
    //
    //   Replace the -1 inside the while condition with a real read() call.
    //   The write() call is already provided -- write n bytes to STDOUT_FD.
    // ------------------------------------------------------------------
    char buf[4096];
    ssize_t n;
    while ((n = /* FILL IN */ -1) > 0) {
        if (write(STDOUT_FD, buf, (size_t)n) < 0) { perror("write"); return 1; }
    }
    if (n < 0) { perror("read"); return 1; }

    // ------------------------------------------------------------------
    // FILL IN 3: Close fd.
    //   Signature: int close(int fd);
    //   Every open() must be matched with a close().
    // ------------------------------------------------------------------
    /* FILL IN */

    return 0;
}
