#include <cstdio>

struct Config {
    int   verbosity;
    const char* label;
};

void print_config(Config* cfg) {
    printf("verbosity=%d label=%s\n", cfg->verbosity, cfg->label);
}

int main() {
    Config* cfg = nullptr;   // BUG: never initialized
    print_config(cfg);       // crashes: dereferences null pointer
    return 0;
}
