// entry_bug.cpp
// Demonstrates what happens when strncpy fills a buffer exactly,
// leaving no room for the null terminator.
#include <cstdio>
#include <cstring>

struct Entry {
    char name[4];
    int  id;
};

// BUG: strncpy(e->name, src, 4) with a 4-character source fills all 4 bytes
// with characters and writes NO null terminator.
// The null terminator that printf expects to find must come from somewhere --
// and it does: from e->id's least-significant byte (0x41 = 'A' before the 0x00).
void set_name(Entry* e, const char* src) {
    strncpy(e->name, src, 4);  // copies 't','e','s','t' into name[0..3] -- no null
}

int main() {
    Entry e;
    e.id = 65;                  // 65 = 0x41 = 'A' in ASCII (little-endian: bytes are 0x41, 0x00, 0x00, 0x00)
    set_name(&e, "test");       // fills name with 't','e','s','t' -- no null terminator

    // printf reads past name[3] into e.id's bytes: sees 'A' (0x41) then 0x00.
    // The output is "testA" -- the 'A' leaked in from e.id.
    printf("name: [%s] id=%d\n", e.name, e.id);
    return 0;
}
