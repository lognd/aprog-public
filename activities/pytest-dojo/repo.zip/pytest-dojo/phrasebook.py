"""A tiny English-to-Spanish phrasebook with save/load support."""

import json

PHRASES: dict[str, str] = {
    "hello": "hola",
    "goodbye": "adios",
    "please": "por favor",
    "thank you": "gracias",
    "cheese": "queso",
    "where is the library": "donde esta la biblioteca",
}


def translate(phrase: str) -> str:
    """Look up a phrase; raise ValueError if the book has no entry for it."""
    key = phrase.strip().lower()
    if key not in PHRASES:
        raise ValueError(f"no translation for {phrase!r}")
    return PHRASES[key]


def shout(phrase: str) -> str:
    """Uppercase a phrase and add emphasis: 'hola' -> 'HOLA!'"""
    return phrase.upper() + "!"


def save_phrasebook(path: str, entries: dict[str, str]) -> None:
    """Write a phrasebook dictionary to a JSON file."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entries, f, indent=2, sort_keys=True)


def load_phrasebook(path: str) -> dict[str, str]:
    """Read a phrasebook dictionary back from a JSON file."""
    with open(path, encoding="utf-8") as f:
        return json.load(f)
