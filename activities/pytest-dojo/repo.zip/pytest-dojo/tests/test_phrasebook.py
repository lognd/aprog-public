"""Tests for the phrasebook.  Run with: pytest -q

One existing test is BROKEN -- run pytest, read the failure report,
and fix the assertion. Then write the four tests described in the
README (the checker looks them up by these exact names):

  1. test_translate_pairs          -- @pytest.mark.parametrize, 3+ cases
  2. test_translate_rejects_unknown -- with pytest.raises(ValueError)
  3. test_phrasebook_roundtrip      -- uses the tmp_path fixture
  4. test_full_dictionary_scan      -- marked @pytest.mark.slow
"""

from phrasebook import shout


def test_shout_adds_emphasis():
    assert shout("hola") == "HOLA"
