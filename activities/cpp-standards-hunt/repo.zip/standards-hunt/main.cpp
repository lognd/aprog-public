#include <algorithm>
#include <iostream>
#include <numeric>
#include <utility>
#include <vector>

int main() {
    std::vector<int> scores = {72, 85, 91, 60, 88};

    // check out: std::accumulate
    int total1 = std::accumulate(scores.begin(), scores.end(), 0);
    std::cout << "sum (accum): " << total1 << "\n";

    // check out: lambda
    auto above_avg = [](int x) { return x > 79; };
    int count = 0;
    for (int s : scores) if (above_avg(s)) ++count;
    std::cout << "above 79: " << count << "\n";

    // look up: std::exchange
    int threshold = 70;
    int prev = std::exchange(threshold, 80);
    std::cout << "threshold: " << prev << " -> " << threshold << "\n";

    // look up: std::cbegin / std::cend
    int hi = *std::max_element(std::cbegin(scores), std::cend(scores));
    std::cout << "max: " << hi << "\n";

    // look up: std::reduce
    int total2 = std::reduce(scores.begin(), scores.end());
    std::cout << "sum (reduce): " << total2 << "\n";

    std::cout << __cplusplus << "\n";
    return 0;
}
