#include <array>
#include <cstdio>

int main() {
    int n = 3;
    std::array<int, n> arr = {10, 20, 30};

    int total = 0;
    for (int x : arr)
        total += x;

    std::printf("Sum = %d\n", total);
    return 0;
}
