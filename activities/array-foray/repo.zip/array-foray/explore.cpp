// explore.cpp  --  compile and run this first
//
//    make explore && ./explore
//
// Read every line of the output before moving on to main.cpp.

#include <array>
#include <cstdio>
#include <vector>

int main() {
    // sizeof(T) tells you how many bytes a value of type T occupies.
    std::printf("  sizeof(std::array<int,  1>) = %zu\n", sizeof(std::array<int,  1>));
    std::printf("  sizeof(std::array<int,  3>) = %zu\n", sizeof(std::array<int,  3>));
    std::printf("  sizeof(std::array<int, 10>) = %zu\n", sizeof(std::array<int, 10>));
    std::printf("\n");
    std::printf("  sizeof(std::vector<int>)    = %zu\n", sizeof(std::vector<int>));
    std::printf("  (the same no matter how many elements the vector holds --\n");
    std::printf("   its elements live somewhere else entirely)\n");
    std::printf("\n");

    // Every local variable in a function lives in the same region of memory
    // called the stack.  std::array elements are part of the variable itself,
    // so they live on the stack too.  std::vector elements live elsewhere.
    std::array<int, 3> arr = {10, 20, 30};
    std::vector<int>   vec = {10, 20, 30};
    int local = 42;

    std::printf("  address of local      : %p\n", (void*)&local);
    std::printf("  address of arr[0]     : %p\n", (void*)&arr[0]);
    std::printf("  address of vec[0]     : %p\n", (void*)vec.data());
    std::printf("\n");
    std::printf("  local and arr[0] have similar addresses -- same stack frame.\n");
    std::printf("  vec[0] is far away -- its elements are on the heap.\n");
    std::printf("\n");

    std::printf("  The size of a std::array must be fixed at compile time\n");
    std::printf("  because the compiler needs it to lay out the stack frame.\n\n");

    return 0;
}
