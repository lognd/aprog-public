Start with explore, then fix main.cpp.

    make explore && ./explore     (read every line of the output)
    make                          (see the compile error)
    (edit main.cpp)
    make run                      (compile and run the fixed program)

When it runs successfully it prints a word.
Type that word into launch.py.

See the top-level README.md for the full walk-through.
