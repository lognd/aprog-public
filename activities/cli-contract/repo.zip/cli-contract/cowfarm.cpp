#include <cstring>
#include <iostream>
#include <string>

static void usage(const char* prog) {
    std::cout << "usage: " << prog
              << " [-h|--help] [--list] CHARACTER MESSAGE\n";
}

static void print_box(const std::string& msg) {
    int w = static_cast<int>(msg.size());
    std::cout << " ";
    for (int i = 0; i < w + 2; i++) std::cout << '_';
    std::cout << "\n< " << msg << " >\n ";
    for (int i = 0; i < w + 2; i++) std::cout << '-';
    std::cout << "\n";
}

static void gerald(const std::string& msg) {
    print_box(msg);
    std::cout <<
        "        \\   ^__^\n"
        "         \\  (oo)\\_______\n"
        "            (__)\\       )\\/\\\n"
        "                ||----w |\n"
        "                ||     ||\n";
}

static void horatio(const std::string& msg) {
    print_box(msg);
    std::cout <<
        "        \\    ___\n"
        "         \\  |   |\n"
        "            |___|\n"
        "            ^__^\n"
        "           (oo)\\_______\n"
        "            (__)\\ )\\/\\\n"
        "                ||--w|\n"
        "                ||   ||\n";
}

static void beatrice(const std::string& msg) {
    print_box(msg);
    std::cout <<
        "    \\\n"
        "     \\   @'--'\n"
        "      \\ (  o_o)\n"
        "         )   (\n"
        "        /|   |\\\n"
        "       (_|   |_)\n";
}

static void rex(const std::string& msg) {
    print_box(msg);
    std::cout <<
        "            \\\n"
        "             \\  __\n"
        "              \\/o \\\n"
        "              /  . |\n"
        "             |  /\\ |\n"
        "              \\/  \\/\n";
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        usage(argv[0]);
        return 1;
    }

    const char* a1 = argv[1];
    if (std::strcmp(a1, "-h") == 0 || std::strcmp(a1, "--help") == 0) {
        std::cout << "usage: " << argv[0]
                  << " [-h|--help] [--list] CHARACTER MESSAGE\n\n"
                  << "Characters: use --list to see available characters.\n\n"
                  << "Options:\n"
                  << "  -h, --help    show this help and exit\n"
                  << "  --list        list all available characters\n";
        return 0;
    }

    if (std::strcmp(a1, "--list") == 0) {
        std::cout << "Available characters:\n"
                  << "  gerald    a standard cow\n"
                  << "  horatio   a cow with a top hat\n"
                  << "  beatrice  a philosophical snail\n"
                  << "  rex       a dismissive dinosaur\n";
        return 0;
    }

    if (argc < 3) {
        std::cerr << "error: MESSAGE required\n";
        usage(argv[0]);
        return 1;
    }

    std::string character = argv[1];
    std::string message   = argv[2];

    if (character == "gerald") {
        gerald(message);
    } else if (character == "horatio") {
        horatio(message);
    } else if (character == "beatrice") {
        beatrice(message);
    } else if (character == "rex") {
        rex(message);
    } else {
        std::cerr << "error: unknown character: " << character << "\n";
        std::cerr << "       run --list to see available characters\n";
        usage(argv[0]);
        return 1;
    }

    return 0;
}
