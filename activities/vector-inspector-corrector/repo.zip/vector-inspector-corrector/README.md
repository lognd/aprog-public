Fix the reserve() call, then run the program.
When the output shows zero moves it prints a word.
Type that word into launch.py.

See the top-level README.md for the full walk-through.
