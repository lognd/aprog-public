#include <cstdio>
#include <vector>

int main() {
    const int N = 8;
    std::vector<int> v;

    std::printf("\n  Tracing push_back  (N = %d elements)\n\n", N);
    std::printf("  i   value   size   capacity   data-address\n");
    std::printf("  -   -----   ----   --------   ------------\n");

    void* prev  = nullptr;
    int   moves = 0;

    for (int i = 0; i < N; ++i) {
        v.reserve(i + 1);
        v.push_back(i * i);

        void* cur   = static_cast<void*>(v.data());
        bool  moved = (prev != nullptr && cur != prev);
        if (moved) ++moves;
        prev = cur;

        std::printf("  %d   %5d   %4zu   %8zu   %p%s\n",
                    i, i * i, v.size(), v.capacity(), cur,
                    moved ? "   <-- buffer moved!" : "");
    }

    std::printf("\n  Moves: %d\n\n", moves);
    return 0;
}
