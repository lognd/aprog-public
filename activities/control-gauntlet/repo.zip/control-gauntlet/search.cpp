// search.cpp
#include <cstdio>

static bool is_prime(int n) {
    if (n < 2) return false;
    for (int d = 2; d * d <= n; ++d)
        if (n % d == 0) return false;
    return true;
}

int main() {
    // Find the first prime in [100, 200].
    int first = -1;
    for (int n = 100; n <= 200; ++n) {
        if (is_prime(n)) {
            first = n;
        }
    }
    std::printf("First prime in [100..200]: %d\n", first);
    return 0;
}
