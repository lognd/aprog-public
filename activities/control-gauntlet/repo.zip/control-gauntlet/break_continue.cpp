// break_continue.cpp -- add the two missing keywords.
//
// Loop 1: find the FIRST multiple of 7 in [1..50].
//   Without a break, the loop keeps running and records the LAST multiple.
//   Add  break;  after the assignment so the loop stops at the first match.
//   Expected: first == 7
//
// Loop 2: sum ONLY the ODD numbers in [1..10].
//   Without a continue, even numbers fall through and are added too.
//   Add  continue;  inside the if-block so even numbers are skipped.
//   Expected: sum == 25  (1+3+5+7+9)
//
// Expected output:  First: 7 Sum: 25

#include <cstdio>

int main() {
    int first = -1;
    for (int i = 1; i <= 50; ++i) {
        if (i % 7 == 0) {
            first = i;
        }
    }

    int sum = 0;
    for (int i = 1; i <= 10; ++i) {
        if (i % 2 == 0) {
        }
        sum += i;
    }

    std::printf("First: %d Sum: %d\n", first, sum);
    return 0;
}
