// leap.cpp
#include <cstdio>

// A year is a leap year if:
//   it is divisible by 4
//   EXCEPT centuries (divisible by 100), which are only leap years
//   if also divisible by 400.
//
// Equivalently: (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
static bool is_leap(int y) {
    return (y % 4 == 0 || y % 100 != 0) && y % 400 == 0;
}

int main() {
    // Count leap years in [1900..2000] inclusive.
    int count = 0;
    for (int y = 1900; y <= 2000; ++y)
        if (is_leap(y)) ++count;
    std::printf("Leap years in [1900..2000]: %d\n", count);

    // Spot checks
    std::printf("2000 is%s a leap year\n", is_leap(2000) ? "" : " not");
    std::printf("1900 is%s a leap year\n", is_leap(1900) ? "" : " not");
    std::printf("1996 is%s a leap year\n", is_leap(1996) ? "" : " not");
    return 0;
}
