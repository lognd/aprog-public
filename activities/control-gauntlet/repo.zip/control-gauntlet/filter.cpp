// filter.cpp
#include <cstdio>

int main() {
    // Sum all integers in [1..100] that share no factor with 10.
    // (i.e., not divisible by 2 or 5)
    long long total = 0;
    for (int n = 1; n <= 100; ++n) {
        if (n % 2 == 0 || n % 5 == 0) {
        }
        total += n;
    }
    std::printf("Sum coprime to 10 in [1..100]: %lld\n", total);
    return 0;
}
