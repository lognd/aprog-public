// short_circuit.cpp -- exploration only; nothing to fix here.
// Compile and run, then read the output carefully.
//
//    g++ -std=c++17 -o short_circuit short_circuit.cpp && ./short_circuit

#include <cstdio>

bool is_large(int x) {
    std::printf("    is_large(%d) called\n", x);
    return x > 10;
}

bool is_even(int x) {
    std::printf("    is_even(%d) called\n", x);
    return x % 2 == 0;
}

int main() {
    int arr[] = {3, 12, 7, 20, 5};
    int n = 5;

    std::printf("\n  --- Part 1: && (AND) ---\n");
    std::printf("  Condition: is_large(x) && is_even(x)\n");
    std::printf("  'If the first operand is false, the second is NEVER evaluated.'\n\n");
    for (int i = 0; i < n; ++i) {
        std::printf("  x = %d:\n", arr[i]);
        if (is_large(arr[i]) && is_even(arr[i]))
            std::printf("    -> passes\n");
        else
            std::printf("    -> fails\n");
    }

    std::printf("\n  --- Part 2: || (OR) ---\n");
    std::printf("  Condition: is_large(x) || is_even(x)\n");
    std::printf("  'If the first operand is true, the second is NEVER evaluated.'\n\n");
    for (int i = 0; i < n; ++i) {
        std::printf("  x = %d:\n", arr[i]);
        if (is_large(arr[i]) || is_even(arr[i]))
            std::printf("    -> passes\n");
        else
            std::printf("    -> fails\n");
    }

    std::printf("\n  Notice which calls were skipped entirely.\n");
    std::printf("  Now open demorgan.cpp.\n\n");
    return 0;
}
