// demorgan.cpp -- fix the bug in keep().
//
// Goal: keep a number if it is NOT (negative AND odd at the same time).
// In other words: keep non-negative numbers, OR even numbers, OR both.
//
// De Morgan's law:  !(A && B) == !A || !B
//                   !(A || B) == !A && !B
//
// The condition below uses the wrong operator inside the !( ).
// One character needs to change.  Expected output: Kept: 5

#include <cstdio>

bool keep(int n) {
    return !(n < 0 || n % 2 != 0);
}

int main() {
    int data[] = {-3, -2, -1, 0, 1, 2, 3};
    int kept = 0;
    for (int i = 0; i < 7; ++i)
        if (keep(data[i])) kept++;
    std::printf("Kept: %d\n", kept);
    return 0;
}
