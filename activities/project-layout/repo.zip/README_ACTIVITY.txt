Read CMakeLists.txt. It tells you exactly where each file belongs.
