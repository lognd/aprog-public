#pragma once
#include <string>
#include <vector>

double compute_average(const std::vector<double>& grades);
std::string letter_grade(double avg);
