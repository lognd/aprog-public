#include "gradelib.hpp"

double compute_average(const std::vector<double>& grades) {
    if (grades.empty()) return 0.0;
    double sum = 0.0;
    for (double g : grades) sum += g;
    return sum / static_cast<double>(grades.size());
}

std::string letter_grade(double avg) {
    if (avg >= 90.0) return "A";
    if (avg >= 80.0) return "B";
    if (avg >= 70.0) return "C";
    if (avg >= 60.0) return "D";
    return "F";
}
