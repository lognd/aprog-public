#include <iostream>
#include <vector>
#include "gradelib.hpp"

int main() {
    std::vector<double> grades = {60, 70, 80, 90, 100};
    double avg = compute_average(grades);
    std::cout << "Average: " << avg << "\n";
    std::cout << "Grade: " << letter_grade(avg) << "\n";
    return 0;
}
