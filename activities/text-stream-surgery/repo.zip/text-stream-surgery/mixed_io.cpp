// mixed_io.cpp -- read a name and bio from profile.txt and print them
//
// The name prints correctly but the bio is always empty.
// Think about what is left in the stream buffer after operator>>.
#include <fstream>
#include <iostream>
#include <string>

int main() {
    std::ifstream f("profile.txt");
    std::string name, bio;
    f >> name;              // BUG: leaves '\n' in the stream buffer
    std::getline(f, bio);  // reads the leftover '\n' -- bio is empty
    std::cout << name << ": " << bio << "\n";
}
