// no_check.cpp -- count lines in missing.txt
//
// This program has a problem when the file does not exist.
// Add the check that makes the missing-file case visible instead of silent.
#include <fstream>
#include <iostream>
#include <string>

int main() {
    std::ifstream f("missing.txt");
    // BUG: no is_open() check -- silently reads nothing when file is absent
    int count = 0;
    std::string line;
    while (std::getline(f, line)) {
        count++;
    }
    std::cout << "Lines: " << count << "\n";
}
