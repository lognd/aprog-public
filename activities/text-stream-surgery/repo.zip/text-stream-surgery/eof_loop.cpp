// eof_loop.cpp -- sum the integers in numbers.txt
//
// Something is wrong with this program.
// Hint: how does eof() behave relative to the read that triggers it?
#include <fstream>
#include <iostream>

int main() {
    std::ifstream f("numbers.txt");
    int n, sum = 0;
    while (!f.eof()) {      // BUG: eof is set AFTER the failed read, not before
        f >> n;
        sum += n;
    }
    std::cout << "Sum: " << sum << "\n";
}
