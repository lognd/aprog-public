#include <cstdio>

#include "mathx.hpp"

int main() {
    printf("add: %d\n", mx_add(3, 4));
    printf("mul: %d\n", mx_mul(3, 4));
}
