#include "mathx.hpp"

int mx_mul(int a, int b) { return a * b; }
