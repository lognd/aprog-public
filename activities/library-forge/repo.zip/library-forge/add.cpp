#include "mathx.hpp"

int mx_add(int a, int b) { return a + b; }
