#ifndef MATHX_HPP
#define MATHX_HPP

int mx_add(int a, int b);
int mx_mul(int a, int b);

#endif
