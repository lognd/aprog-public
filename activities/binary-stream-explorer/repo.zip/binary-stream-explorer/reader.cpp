// reader.cpp -- read records from data.bin
//
// The file format:
//   [0..3]   magic bytes "APRO" (4 bytes)
//   [4..5]   record count (uint16_t, little-endian, 2 bytes)
//   [6..]    records back-to-back, each exactly sizeof(Record) bytes
//
// struct Record layout (16 bytes total):
//   id    -- int32_t  (4 bytes)
//   score -- int32_t  (4 bytes)
//   name  -- char[8]  (8 bytes, null-padded)
//
// Your task: fill in the three blanks marked BLANK_A, BLANK_B, BLANK_C.
// Use the hex dump shown in the banner and sizeof() to compute offsets.
// Do NOT hardcode magic numbers -- use sizeof() where possible.
//
// Expected output (after all three blanks are correct):
//   Records: 3
//   ID: 2
//   Score: 80
//   Name: Bob
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>

struct Record {
    int32_t id;
    int32_t score;
    char    name[8];
};

int main() {
    std::ifstream f("data.bin", std::ios::binary);
    if (!f.is_open()) {
        std::cerr << "error: cannot open data.bin\n";
        return 1;
    }

    // Read and verify the magic number.
    char magic[4];
    f.read(magic, 4);
    if (std::strncmp(magic, "APRO", 4) != 0) {
        std::cerr << "error: bad magic number\n";
        return 1;
    }

    // Read the record count (uint16_t).
    uint16_t count = 0;
    f.read(reinterpret_cast<char*>(&count), /* BLANK_A: how many bytes? */ 0);

    std::cout << "Records: " << count << "\n";

    // Seek to record at index 1 (the second record, 0-indexed).
    // The header ends at byte 6.  Each record is sizeof(Record) bytes.
    f.seekg(/* BLANK_B: byte offset of record index 1 */ 0);

    // Read one full record.
    Record r{};
    f.read(reinterpret_cast<char*>(&r), /* BLANK_C: how many bytes? */ 0);

    std::cout << "ID: "    << r.id    << "\n";
    std::cout << "Score: " << r.score << "\n";
    std::cout << "Name: "  << r.name  << "\n";
    return 0;
}
