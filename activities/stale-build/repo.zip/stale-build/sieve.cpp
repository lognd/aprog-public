#include "limits.h"

// Returns the count of primes in [2, SIEVE_LIMIT].
int prime_count() {
    int count = 0;
    for (int n = 2; n <= SIEVE_LIMIT; ++n) {
        bool is_prime = true;
        for (int d = 2; d * d <= n; ++d) {
            if (n % d == 0) {
                is_prime = false;
                break;
            }
        }
        if (is_prime)
            ++count;
    }
    return count;
}
