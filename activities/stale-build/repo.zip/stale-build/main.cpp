#include <cstdio>
#include "limits.h"

int prime_count();

int main() {
    std::printf("Primes up to %d: %d\n", SIEVE_LIMIT, prime_count());
    return 0;
}
