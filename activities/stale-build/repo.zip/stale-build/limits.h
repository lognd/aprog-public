#ifndef LIMITS_H
#define LIMITS_H

static const int SIEVE_LIMIT = 10000;

#endif
