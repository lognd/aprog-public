#include <cstdint>
#include <cstdio>

// A union lets all its members occupy the SAME block of memory.
// The size of the union is the size of its largest member.
// Writing through one member and reading through another gives you
// a different "interpretation" of the same bytes -- no conversion,
// no copy, just a reinterpretation of whatever bits are sitting there.

union ByteView {
    uint32_t      as_uint;    // interpret 4 bytes as an unsigned 32-bit integer
    float         as_float;   // interpret the same 4 bytes as an IEEE 754 float
    unsigned char bytes[4];   // interpret the same 4 bytes one-by-one
};

int main() {
    ByteView bv;

    // -----------------------------------------------------------------------
    // TODO 1: Store the bit pattern for 1.0f and read it back as a float.
    //
    // The IEEE 754 bit pattern for positive 1.0 is 0x3F800000.
    // Store that value into bv.as_uint, then read bv.as_float and print it.
    //
    // Expected output line:
    //   as_float: 1
    //
    // Use:  printf("as_float: %g\n", ...);
    // -----------------------------------------------------------------------

    // YOUR CODE HERE (TODO 1)



    // -----------------------------------------------------------------------
    // TODO 2: Print all 4 bytes of bv in hexadecimal.
    //
    // Loop over bv.bytes[0] through bv.bytes[3] and print each as a
    // 2-digit lowercase hex number.  Separate bytes with a single space.
    //
    // On a little-endian machine (x86/x64), the LEAST significant byte
    // of 0x3F800000 is stored at the lowest address, so bytes[0] == 0x00,
    // bytes[1] == 0x00, bytes[2] == 0x80, bytes[3] == 0x3f.
    //
    // Expected output line:
    //   bytes: 00 00 80 3f
    //
    // Use:  printf("bytes:");  then inside a loop: printf(" %02x", bv.bytes[i]);
    // Finish with: printf("\n");
    // -----------------------------------------------------------------------

    // YOUR CODE HERE (TODO 2)



    // -----------------------------------------------------------------------
    // TODO 3: Store negative zero as a float and inspect its bit pattern.
    //
    // In IEEE 754, -0.0f has the sign bit set and all other bits zero,
    // giving the bit pattern 0x80000000.
    //
    // Store -0.0f into bv.as_float, then print bv.as_uint as hex.
    //
    // Expected output line:
    //   neg_zero_bits: 80000000
    //
    // Use:  printf("neg_zero_bits: %08x\n", bv.as_uint);
    // -----------------------------------------------------------------------

    // YOUR CODE HERE (TODO 3)



    // -----------------------------------------------------------------------
    // TODO 4: Print the size of the union.
    //
    // The size of a union equals the size of its largest member.
    // Here, uint32_t, float, and unsigned char[4] are all 4 bytes,
    // so sizeof(ByteView) should be 4.
    //
    // Expected output line:
    //   sizeof(ByteView): 4
    //
    // Use:  printf("sizeof(ByteView): %zu\n", sizeof(ByteView));
    // -----------------------------------------------------------------------

    // YOUR CODE HERE (TODO 4)



    return 0;
}
