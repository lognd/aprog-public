#include <cstddef>
#include <cstdio>
#include <cstdint>

// ============================================================
// Struct A: no explicit packing
//
// The compiler is free to insert padding between fields so
// that each field starts at an address that is a multiple of
// its own size.  This is called natural alignment.
// ============================================================
struct Unpacked {
    char   a;     // 1 byte
    int    b;     // 4 bytes  (must start at a multiple of 4)
    char   c;     // 1 byte
    double d;     // 8 bytes  (must start at a multiple of 8)
};

// ============================================================
// Struct B: packing forced to 1-byte alignment
//
// #pragma pack(push, 1) saves the current packing setting on a
// stack and switches to 1-byte alignment.  No padding bytes
// are inserted between fields.
//
// #pragma pack(pop) restores the saved setting.  ALWAYS use
// pop after push, or subsequent structs in this file will also
// be packed -- a hard-to-debug bug.
// ============================================================
#pragma pack(push, 1)
struct Packed {
    char   a;
    int    b;
    char   c;
    double d;
};
#pragma pack(pop)

// ============================================================
// Struct C: same fields as Unpacked, but reordered
//
// By placing the largest field first, we can keep everything
// naturally aligned without inserting padding between fields.
// A small amount of trailing padding may still appear so that
// the struct's total size is a multiple of its alignment.
// ============================================================
struct Reordered {
    double d;     // 8 bytes at offset 0
    int    b;     // 4 bytes at offset 8
    char   a;     // 1 byte  at offset 12
    char   c;     // 1 byte  at offset 13
    // 2 bytes of trailing padding (total must be multiple of 8)
};

// ============================================================
// Struct D: all fields are the same size (no padding needed)
// ============================================================
struct Simple {
    uint8_t x;
    uint8_t y;
    uint8_t z;
};

int main() {
    // ----------------------------------------------------------
    // TODO 1: Print sizeof for each struct.
    // Use this exact format: printf("sizeof(Unpacked) = %zu\n", sizeof(Unpacked));
    // Do this for Unpacked, Packed, Reordered, and Simple.
    // ----------------------------------------------------------


    // ----------------------------------------------------------
    // TODO 2: Print offsetof for every field in Unpacked.
    // Use this exact format: printf("offsetof(Unpacked, a) = %zu\n", offsetof(Unpacked, a));
    // Fields in order: a, b, c, d
    // ----------------------------------------------------------


    // ----------------------------------------------------------
    // TODO 3: Print offsetof for every field in Packed.
    // Same format, same field order: a, b, c, d
    // ----------------------------------------------------------


    // ----------------------------------------------------------
    // TODO 4: Print offsetof for every field in Reordered.
    // Same format, field order: d, b, a, c
    // ----------------------------------------------------------


    // ----------------------------------------------------------
    // TODO 5: Print sizeof(Simple) and offsetof(Simple, z).
    // (Two lines total.)
    // ----------------------------------------------------------


    return 0;
}
