// clock.cpp -- timing comparison: four ways to compute sum(1..N)
// All four give the same answer.  Watch how long each one takes.
//
// Compiled without optimization (-O0) so every loop iteration actually runs.

#include <cstdio>
#include <ctime>

static const int N = 30000;

// ---- Alice: one math expression -----------------------------------------
long long alice() {
    return (long long)N * (N + 1) / 2;
}

// ---- Bob: one loop -------------------------------------------------------
long long bob() {
    long long total = 0;
    for (int i = 1; i <= N; ++i)
        total += i;
    return total;
}

// ---- Carol: nested loops, inner runs from 1 to i ------------------------
long long carol() {
    long long total = 0;
    for (int i = 1; i <= N; ++i)
        for (int j = 1; j <= i; ++j)
            total++;
    return total;
}

// ---- Dave: nested loops, inner always runs from 1 to N ------------------
long long dave() {
    long long total = 0;
    for (int k = 1; k <= N; ++k)
        for (int i = 1; i <= N; ++i)
            if (i == k) total += i;
    return total;
}

// ---- timing helper -------------------------------------------------------
static double ms_since(clock_t t0) {
    return (clock() - t0) * 1000.0 / CLOCKS_PER_SEC;
}

int main() {
    std::printf("\n");
    std::printf("  Computing sum(1 + 2 + ... + %d) four ways:\n", N);
    std::printf("\n");
    std::printf("  %-32s  %-14s  %s\n", "Approach", "Answer", "Time");
    std::printf("  %-32s  %-14s  %s\n",
                "--------------------------------",
                "--------------",
                "--------");

    clock_t t;
    long long result;

    t = clock(); result = alice();
    std::printf("  %-32s  %-14lld  %.1f ms\n", "Alice  (formula)", result, ms_since(t));

    t = clock(); result = bob();
    std::printf("  %-32s  %-14lld  %.1f ms\n", "Bob    (one loop)", result, ms_since(t));

    t = clock(); result = carol();
    std::printf("  %-32s  %-14lld  %.1f ms\n", "Carol  (nested, j <= i)", result, ms_since(t));

    t = clock(); result = dave();
    std::printf("  %-32s  %-14lld  %.1f ms\n", "Dave   (nested, full grid)", result, ms_since(t));

    std::printf("\n");
    std::printf("  All four give the same answer.\n");
    std::printf("  Look at the time column.  Now open the quiz and explain why.\n");
    std::printf("\n");
    return 0;
}
