// clock.cpp -- seven ways to compute sum(1..N)
// All seven give the same answer.
// Compiled without -O2 so every iteration actually runs.

#include <cstdio>
#include <ctime>

static const int N = 40000;

// ---- alice ---------------------------------------------------------------
long long alice() {
    return (long long)N * (N + 1) / 2;
}

// ---- bob -----------------------------------------------------------------
long long bob() {
    long long total = 0;
    for (int i = 1; i <= N; ++i) {
        for (int j = 0; j < N; ++j) {
            total += i;
            break;
        }
    }
    return total;
}

// ---- carol's helper ------------------------------------------------------
static int tally(int k) {
    int n = 0;
    for (int i = 0; i < k; ++i) ++n;
    return n;
}

// ---- carol ---------------------------------------------------------------
long long carol() {
    long long total = 0;
    for (int i = 1; i <= N; ++i)
        total += tally(i);
    return total;
}

// ---- dave ----------------------------------------------------------------
long long dave() {
    long long total = 0;
    int i = 0;
    do {
        total += ++i;
    } while (i < N);
    return total;
}

// ---- eve -----------------------------------------------------------------
long long eve() {
    long long lower = 0, upper = 0;
    int i = 0;
    while (i < N) {
        ++i;
        if (i <= N / 2) { lower += i; continue; }
        upper += i;
    }
    return lower + upper;
}

// ---- frank ---------------------------------------------------------------
long long frank() {
    long long a = 0, b = 0, c = 0, d = 0;
    for (int i = 1; i <= N; ++i) {
        switch (i % 4) {
            case 0: a += i; break;
            case 1: b += i; break;
            case 2: c += i; break;
            case 3: d += i; break;
        }
    }
    return a + b + c + d;
}

// ---- grace ---------------------------------------------------------------
long long grace() {
    long long total = 0;
    for (int i = N; i >= 1; --i) {
        if (i > (N * 3) / 4) { total += i; continue; }
        if (i > N / 2)        { total += i; continue; }
        if (i > N / 4)        { total += i; continue; }
        total += i;
    }
    return total;
}

// ---- timing helper -------------------------------------------------------
static double ms_since(clock_t t0) {
    return (clock() - t0) * 1000.0 / CLOCKS_PER_SEC;
}

int main() {
    std::printf("\n");
    std::printf("  Computing sum(1 + 2 + ... + %d) seven ways:\n", N);
    std::printf("\n");
    std::printf("  %-8s  %-16s  %s\n", "Name", "Answer", "Time");
    std::printf("  %-8s  %-16s  %s\n",
                "--------", "----------------", "--------");

    clock_t t;
    long long result;

    t = clock(); result = alice();
    std::printf("  %-8s  %-16lld  %.1f ms\n", "alice", result, ms_since(t));

    t = clock(); result = bob();
    std::printf("  %-8s  %-16lld  %.1f ms\n", "bob",   result, ms_since(t));

    t = clock(); result = carol();
    std::printf("  %-8s  %-16lld  %.1f ms\n", "carol", result, ms_since(t));

    t = clock(); result = dave();
    std::printf("  %-8s  %-16lld  %.1f ms\n", "dave",  result, ms_since(t));

    t = clock(); result = eve();
    std::printf("  %-8s  %-16lld  %.1f ms\n", "eve",   result, ms_since(t));

    t = clock(); result = frank();
    std::printf("  %-8s  %-16lld  %.1f ms\n", "frank", result, ms_since(t));

    t = clock(); result = grace();
    std::printf("  %-8s  %-16lld  %.1f ms\n", "grace", result, ms_since(t));

    std::printf("\n");
    std::printf("  All seven give the same answer: %lld\n", result);
    std::printf("\n");
    return 0;
}
