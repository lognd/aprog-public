/*
 * shell_check.c -- Activity: Get a Linux/Unix Shell
 *
 * The passphrase is XOR-encoded at compile time via -D flags produced
 * by encode.py. The Windows build omits -DENCODED_* entirely; the
 * _WIN32 branch only prints an error message pointing students to WSL.
 *
 * Build instructions are in the GitHub Actions workflow.
 */

#include <stdio.h>
#include <string.h>

#define _LINE  "----------------------------------------------------------------------"
#define _DLINE "======================================================================"

static void _hr(void)  { puts(_LINE);  }
static void _dhr(void) { puts(_DLINE); }

static void _banner(const char *title)
{
    int w = 70, tlen = (int)strlen(title);
    int pad = (w - tlen - 2) / 2;
    _dhr();
    for (int i = 0; i < pad; i++) putchar(' ');
    printf(" %s ", title);
    for (int i = 0; i < pad; i++) putchar(' ');
    putchar('\n');
    _dhr();
}

#ifndef _WIN32

#ifndef ENCODED_LEN
#  error "Compile with -DENCODED_LEN=N -DENCODED_BYTES='0xAA,0xBB,...'"
#endif

/* XOR key -- must match encode.py */
static const unsigned char _K[] = "cs-env-xkey-2024";
static const unsigned char _E[] = { ENCODED_BYTES };

static void _reveal(void)
{
    int klen = (int)(sizeof(_K) - 1);
    for (int i = 0; i < ENCODED_LEN; i++)
        putchar((char)(_E[i] ^ _K[i % klen]));
    putchar('\n');
}

int main(void)
{
    _banner("Activity: Get a Linux/Unix Shell");
    printf("\n");
    printf("  Platform check ... PASSED\n");
    printf("  You are running in a Unix-like environment.\n");
    printf("\n");
    _hr();
    printf("  Passphrase: ");
    _reveal();
    _hr();
    printf("\n");
    printf("  Submit this passphrase to your instructor.\n");
    printf("\n");
    return 0;
}

#else  /* _WIN32 */

int main(void)
{
    _banner("Activity: Get a Linux/Unix Shell");
    printf("\n");
    printf("  Platform check ... FAILED\n");
    printf("\n");
    printf("  You are running this on Windows directly.\n");
    printf("  This activity requires a Linux or macOS terminal.\n");
    printf("\n");
    _hr();
    printf("  NEXT STEPS\n");
    _hr();
    printf("\n");
    printf("  Windows users: install WSL2, then run the linux-x86_64\n");
    printf("  or linux-aarch64 binary from inside the WSL terminal.\n");
    printf("\n");
    printf("  See README.md for complete setup instructions.\n");
    printf("\n");
    _hr();
    printf("\n");
    printf("  Press Enter to close.\n");
    getchar();
    return 1;
}

#endif /* _WIN32 */
