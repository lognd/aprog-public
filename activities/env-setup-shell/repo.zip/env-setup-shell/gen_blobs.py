#!/usr/bin/env python3
"""
Generate and write _BLOB values for all env-setup-* activity launch.py files.

Reads passphrases from aprog-private/activities/passcodes.json.
Writes the computed _BLOB string directly into each launch.py file by
replacing the line that starts with '_BLOB = "'.

Usage:
  python3 gen_blobs.py           # write blobs into launch.py files
  python3 gen_blobs.py --dry-run # print blobs only, do not write files

Called automatically by aprog-private/scripts/generate_activities.py.
"""
import argparse
import hashlib as _hl
import hmac as _hm
import json
import pathlib
import re
import sys

_SALT      = bytes.fromhex("a3f1b2c4d5e6f7a8b9c0d1e2f3a4b5c6")
_KDF_ITERS = 100000

_THIS_DIR  = pathlib.Path(__file__).resolve().parent
_PRIV_ROOT = _THIS_DIR.parent.parent          # aprog-private/
_PASSCODES = _PRIV_ROOT / "activities" / "passcodes.json"
_PUB_ACTS  = _PRIV_ROOT.parent / "aprog-public" / "activities"

# slug -> list of exact answer strings used as the blob key
_ENV_SETUP_ANSWERS: dict[str, list[str]] = {
    "env-setup-compiler":    ["gcc-verified", "gxx-verified"],
    "env-setup-build-tools": ["cmake-verified", "make-verified"],
    "env-setup-python":      ["python-verified", "pip-verified"],
    "env-setup-ide":         ["ide-verified"],
    "env-setup-git":         ["git-verified", "gh-verified"],
}


def _load_passphrase(slug: str) -> str:
    data = json.loads(_PASSCODES.read_text())
    for entry in data:
        if entry["slug"] == slug:
            return entry["passphrase"]
    raise KeyError(f"slug {slug!r} not found in {_PASSCODES}")


def _derive_key(answers: list[str]) -> bytes:
    return _hl.pbkdf2_hmac("sha256", "|".join(answers).encode(), _SALT, _KDF_ITERS)


def _stream(key: bytes, length: int) -> bytes:
    ks, i = b"", 0
    while len(ks) < length:
        ks += _hl.sha256(key + i.to_bytes(4, "little")).digest()
        i += 1
    return ks[:length]


def _encrypt(answers: list[str], passphrase: str) -> str:
    key = _derive_key(answers)
    pt  = passphrase.encode()
    ct  = bytes(a ^ b for a, b in zip(pt, _stream(key, len(pt))))
    mac = _hm.new(key, ct, _hl.sha256).digest()
    return (ct + mac).hex()


def _patch_launch_py(slug: str, blob: str) -> None:
    path = _PUB_ACTS / slug / "launch.py"
    if not path.exists():
        print(f"  [skip] {path} not found", file=sys.stderr)
        return
    text = path.read_text(encoding="utf-8")
    replacement = f'_BLOB = "{blob}"'
    new_text = re.sub(r'^_BLOB = ".*"$', replacement, text, flags=re.MULTILINE)
    if new_text == text:
        if replacement in text:
            print(f"  ok     activities/{slug}/launch.py  (already current)")
        else:
            print(f"  [warn] no _BLOB line found in {path}", file=sys.stderr)
        return
    path.write_text(new_text, encoding="utf-8")
    print(f"  wrote  activities/{slug}/launch.py  (blob updated)")


def run(dry_run: bool = False) -> None:
    blobs = {}
    for slug, answers in _ENV_SETUP_ANSWERS.items():
        passphrase = _load_passphrase(slug)
        blobs[slug] = _encrypt(answers, passphrase)

    for slug, blob in blobs.items():
        print(f"  # activities/{slug}/launch.py")
        print(f'  _BLOB = "{blob}"')
        print()

    print("  # env-setup-shell passphrase (set as SHELL_CHECK_PASSPHRASE in aprog-private):")
    print(f'  # "{_load_passphrase("env-setup-shell")}"')
    print()
    print("  # env-setup-discord passphrase (hardcoded in README.md):")
    print(f'  # "{_load_passphrase("env-setup-discord")}"')
    print()

    if dry_run:
        print("  --dry-run: skipping file writes.")
        return

    if not _PUB_ACTS.exists():
        print(f"  [error] aprog-public/activities not found at {_PUB_ACTS}", file=sys.stderr)
        sys.exit(1)

    print("  Writing blobs into launch.py files...")
    for slug, blob in blobs.items():
        _patch_launch_py(slug, blob)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dry-run", action="store_true",
                    help="Print blobs only; do not write any files.")
    args = ap.parse_args()
    run(dry_run=args.dry_run)
