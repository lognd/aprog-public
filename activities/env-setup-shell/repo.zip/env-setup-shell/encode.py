#!/usr/bin/env python3
"""
Encode a passphrase for embedding in shell_check.c.

Usage:
  python3 encode.py "my-secret-passphrase"

Stdout (two lines):
  Line 1: comma-separated hex bytes  -> -DENCODED_BYTES='...'
  Line 2: integer length             -> -DENCODED_LEN=N
"""
import sys

_KEY = b"cs-env-xkey-2024"


def encode(passphrase: str) -> tuple[str, int]:
    p = passphrase.encode()
    n = len(p)
    encoded = bytes(a ^ _KEY[i % len(_KEY)] for i, a in enumerate(p))
    hex_list = ",".join(f"0x{b:02x}" for b in encoded)
    return hex_list, n


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"usage: {sys.argv[0]} PASSPHRASE", file=sys.stderr)
        sys.exit(1)
    hex_list, n = encode(sys.argv[1])
    print(hex_list)
    print(n)
