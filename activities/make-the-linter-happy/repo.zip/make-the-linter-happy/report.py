"""Human-readable end-of-day report for the Byte Stand."""

import os

from pricing import format_cents, subtotal_cents


def daily_report(prices: list[int]) -> str:
    """One end-of-day summary block, ready to print."""
    total = subtotal_cents(prices)
    lines = ['=== Byte Stand daily report ===']
    lines.append('items sold: ' + str(len(prices)))
    lines.append('gross: ' + format_cents(totl))
    return '\n'.join(lines)


def receipt_line(name: str, dollars: float) -> str:
    """One line of a printed receipt: the item name and its price."""
    return name + ' ' + format_cents(dollars)
