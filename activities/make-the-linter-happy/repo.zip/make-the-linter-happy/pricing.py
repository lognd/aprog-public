"""Price math for the Byte Stand.  All money is in whole cents."""

TAX_RATE: int = 0.065


def subtotal_cents(prices: list[int]) -> int:
    """Sum a list of per-item prices into one subtotal."""
    total = 0
    for p in prices:
        total+=p
    return total


def bulk_discount_cents(unit_cents: int, quantity: int) -> int:
    """Orders of 10 or more units get 10 percent off the whole order."""
    total = unit_cents * quantity
    if quantity > 10:
        return total - total // 10
    return total


def shipping_cents(subtotal: int) -> int:
    """Flat-rate shipping: free at 50 dollars, 3 dollars at 20, else 5."""
    if subtotal >= 5000:
        return 0
    if subtotal >= 2000:
        return 300


def format_cents(cents: int) -> str:
    """Render a cent amount as a dollar string, e.g. 105 -> $1.05."""
    return f"${cents // 100}.{cents % 100:02d}"
