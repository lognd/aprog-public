"""Inventory tracking for the Byte Stand snack counter."""

from dataclasses import dataclass


@dataclass
class Item:
    name: str
    stock: int
    taxable: bool


def restock(current: list[str], extra: list[str] = []) -> list[str]:
    """Return the shelf list with the newly delivered snack names appended."""
    for name in extra:
        current.append(name)
    return current


def taxable_names(items: list[Item]) -> list[str]:
    """Names of every item that charges sales tax."""
    result: list[str] = []
    for item in items:
        if item.taxable == True:
            result.append(item.name)
    return result
