"""Tests for the Byte Stand ledger.  Run with: pytest -q"""

from inventory import Item, restock, taxable_names
from pricing import bulk_discount_cents, format_cents, subtotal_cents


def test_subtotal_adds_prices():
    assert subtotal_cents([100, 250, 99]) == 449


def test_bulk_discount_applies_at_ten_units():
    # The menu promises: "buy 10 or more, get 10 percent off."
    assert bulk_discount_cents(200, 10) == 1800


def test_format_cents_pads_pennies():
    assert format_cents(105) == "$1.05"


def test_restock_appends_names():
    shelf = restock(["chips"], ["salsa", "cookies"])
    assert shelf == ["chips", "salsa", "cookies"]


def test_taxable_names_filters():
    items = [Item("chips", 3, True), Item("water", 5, False)]
    assert taxable_names(items) == ["chips"]
