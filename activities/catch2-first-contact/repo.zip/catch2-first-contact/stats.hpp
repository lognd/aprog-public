#pragma once
#include <vector>

// Returns the arithmetic mean of v.  Returns 0.0 if v is empty.
double mean(const std::vector<double>& v);

// Returns the median of v.
// For an even-length vector, returns the average of the two middle values.
// Returns 0.0 if v is empty.
// The input vector is NOT modified.
double median(const std::vector<double>& v);
