#include <catch2/catch_test_macros.hpp>
#include "stats.hpp"

// -----------------------------------------------------------------------
// mean() tests
// -----------------------------------------------------------------------

TEST_CASE("mean of a single-element vector") {
    // TODO: create a vector with one element and REQUIRE that mean() returns it
}

TEST_CASE("mean of multiple elements") {
    // TODO: test mean({1, 2, 3}) == 2.0
}

TEST_CASE("mean of an empty vector") {
    // TODO: test that mean({}) == 0.0
}

// -----------------------------------------------------------------------
// median() tests
// -----------------------------------------------------------------------

TEST_CASE("median of a sorted odd-length vector") {
    // TODO: test median({1, 2, 3}) == 2.0
}

TEST_CASE("median of an unsorted vector") {
    // TODO: test that median() sorts internally before finding the middle
    //       e.g. median({3, 1, 2}) == 2.0
}

TEST_CASE("median of an even-length vector") {
    // TODO: test that median averages the two middle values
    //       e.g. median({1, 2, 3, 4}) == 2.5
}

TEST_CASE("median of an empty vector") {
    // TODO: test that median({}) == 0.0
}
