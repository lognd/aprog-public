#include "stats.hpp"
#include <algorithm>
#include <numeric>

double mean(const std::vector<double>& v) {
    if (v.empty()) return 0.0;
    return std::accumulate(v.begin(), v.end(), 0.0) / static_cast<double>(v.size());
}

double median(const std::vector<double>& v) {
    if (v.empty()) return 0.0;
    std::vector<double> sorted = v;
    std::sort(sorted.begin(), sorted.end());
    std::size_t n = sorted.size();
    if (n % 2 == 1) {
        return sorted[n / 2];
    } else {
        return (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0;
    }
}
