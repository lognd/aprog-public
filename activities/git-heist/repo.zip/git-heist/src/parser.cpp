#include "parser.h"
#include <cctype>

std::vector<Token> tokenize(const std::string& line) {
    std::vector<Token> tokens;
    std::size_t i = 0;
    while (i < line.size()) {
        if (std::isspace(static_cast<unsigned char>(line[i]))) { ++i; continue; }
        Token tok;
        if (std::isalpha(static_cast<unsigned char>(line[i]))) {
            tok.type = Token::Type::Word;
            while (i < line.size() && std::isalpha(static_cast<unsigned char>(line[i])))
                tok.value += line[i++];
        } else if (std::isdigit(static_cast<unsigned char>(line[i]))) {
            tok.type = Token::Type::Number;
            while (i < line.size() && std::isdigit(static_cast<unsigned char>(line[i])))
                tok.value += line[i++];
        } else {
            tok.type  = Token::Type::Punctuation;
            tok.value = line[i++];
        }
        tokens.push_back(tok);
    }
    return tokens;
}
