#include "parser.h"
#include <iostream>
#include <fstream>
#include <string>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "usage: textproc <file>\n";
        return 1;
    }
    std::ifstream file(argv[1]);
    if (!file) {
        std::cerr << "error: cannot open " << argv[1] << "\n";
        return 1;
    }
    std::string line;
    while (std::getline(file, line)) {
        auto tokens = tokenize(line);
        std::cout << tokens.size() << " tokens\n";
    }
    return 0;
}
