# textproc

A small command-line text processing tool.

## Build

    make

## Usage

    ./textproc <input_file>
