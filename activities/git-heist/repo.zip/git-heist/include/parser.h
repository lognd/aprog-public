#pragma once
#include <string>
#include <vector>

struct Token {
    enum class Type { Word, Number, Punctuation, Unknown };
    Type        type;
    std::string value;
};

std::vector<Token> tokenize(const std::string& line);
