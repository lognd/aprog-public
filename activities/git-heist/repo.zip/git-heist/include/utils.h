#pragma once
#include <string>

std::string trim(const std::string& s);
std::string to_lower(const std::string& s);
