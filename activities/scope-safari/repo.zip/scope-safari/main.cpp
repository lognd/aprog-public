#include <cstdio>

int main() {
    int scores[] = {45, 78, 92, 88, 65, 95, 71, 83};
    int n = 8;

    // ---- Bug 1: shadowing -----------------------------------------------
    // Count scores above 75.  Expected: 5
    int count = 0;
    for (int i = 0; i < n; ++i) {
        int count = 0;
        if (scores[i] > 75)
            count++;
    }
    std::printf("Passing: %d\n", count);

    // ---- Bug 2: variable used outside its scope -------------------------
    // Find the index of the first score above 90.  Expected: 2
    for (int i = 0; i < n; ++i)
        if (scores[i] > 90) break;
    std::printf("Top at: %d\n", i);

    // ---- Bug 3: switch-case initialization jump -------------------------
    // Award bonus points based on the first score.
    // scores[0] = 45  ->  tier = 4  ->  default  ->  bonus = 0
    int tier = scores[0] / 10;
    switch (tier) {
        case 9:
        case 8:
            int bonus = 10;
            std::printf("Bonus: %d\n", bonus);
            break;
        case 7:
            bonus = 5;
            std::printf("Bonus: %d\n", bonus);
            break;
        default:
            bonus = 0;
            std::printf("Bonus: %d\n", bonus);
            break;
    }

    return 0;
}
