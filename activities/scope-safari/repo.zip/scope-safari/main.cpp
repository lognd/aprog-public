// main.cpp
#include <cstdio>

int count_above(int limit, int threshold) {
    static int result = 0;
    for (int i = 1; i <= limit; ++i)
        if (i > threshold)
            result++;
    return result;
}

int main() {
    // Count multiples of 3 in [1..30].  Expected: 10
    int count = 0;
    for (int i = 1; i <= 30; ++i) {
        int count = 0;
        if (i % 3 == 0)
            count++;
    }
    std::printf("Multiples of 3 in [1..30]: %d\n", count);

    // Count integers in [1..10] greater than 7.  Expected: 3
    std::printf("Above 7 in [1..10]: %d\n", count_above(10, 7));

    // Count integers in [1..20] greater than 14.  Expected: 6
    std::printf("Above 14 in [1..20]: %d\n", count_above(20, 14));

    return 0;
}
