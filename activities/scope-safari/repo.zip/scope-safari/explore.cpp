// explore.cpp -- run this to see scope concepts demonstrated.
//
//    make explore && ./explore

#include <cstdio>

// ---- static local variable -----------------------------------------------
// Each call to next_id() picks up where the last one left off.
// Remove 'static' and each call would start from 0 again.
int next_id() {
    static int id = 0;
    return ++id;
}

int main() {
    // ---- 1. Blank scope --------------------------------------------------
    std::printf("  --- 1. Blank scope ---\n");
    int x = 10;
    {
        int x = 99;
        std::printf("  inside  block: x = %d\n", x);
    }
    std::printf("  outside block: x = %d\n\n", x);

    // ---- 2. Loop variable scope ------------------------------------------
    std::printf("  --- 2. Loop variable scope ---\n");
    for (int i = 0; i < 3; ++i)
        std::printf("  inside  loop: i = %d\n", i);
    // 'i' does not exist here
    std::printf("  after loop: 'i' is out of scope\n\n");

    // ---- 3. Shadowing ----------------------------------------------------
    std::printf("  --- 3. Shadowing ---\n");
    int total = 0;
    for (int i = 1; i <= 5; ++i) {
        int total = i * 10;   // new variable, shadows outer
        std::printf("  inner total = %d\n", total);
    }
    std::printf("  outer total = %d  (unchanged)\n\n", total);

    // ---- 4. do-while scope -----------------------------------------------
    std::printf("  --- 4. do-while ---\n");
    int n = 0;
    do {
        std::printf("  body runs, n = %d\n", n);
        n++;
    } while (n < 3);
    std::printf("\n");

    // ---- 5. Static local variable ----------------------------------------
    std::printf("  --- 5. Static local variable ---\n");
    std::printf("  next_id() = %d\n", next_id());
    std::printf("  next_id() = %d\n", next_id());
    std::printf("  next_id() = %d\n", next_id());
    std::printf("  'static int id' keeps its value between calls.\n");
    std::printf("  Without 'static', id would reset to 0 each call.\n\n");

    return 0;
}
