// explore.cpp -- compile and run this first
//
//    make explore && ./explore
//
// Read every section before moving on to main.cpp.

#include <cstdio>

int main() {
    // ---- 1. Blank scope --------------------------------------------------
    std::printf("  --- 1. Blank scope ---\n");
    int x = 10;
    {
        int x = 99;
        std::printf("  inside  block: x = %d\n", x);
    }
    std::printf("  outside block: x = %d\n", x);
    std::printf("  The inner 'x' is a completely separate variable.\n");
    std::printf("  It is created at '{' and destroyed at '}'.\n\n");

    // ---- 2. For-loop variable scope --------------------------------------
    std::printf("  --- 2. For-loop variable scope ---\n");
    for (int i = 0; i < 3; ++i)
        std::printf("  inside loop: i = %d\n", i);
    // Uncomment the next line to see a compile error -- 'i' is gone:
    // std::printf("  after loop: i = %d\n", i);
    std::printf("  'i' does not exist after the closing brace of the loop.\n\n");

    // ---- 3. Shadowing ----------------------------------------------------
    std::printf("  --- 3. Shadowing ---\n");
    int total = 0;
    for (int v = 1; v <= 5; ++v) {
        int total = v * 2;
        std::printf("  inner total = %d\n", total);
    }
    std::printf("  outer total = %d  (outer variable was never touched)\n\n", total);

    // ---- 4. Switch-case scope --------------------------------------------
    std::printf("  --- 4. Switch-case scope ---\n");
    std::printf("  All case labels share one scope unless you add braces.\n");
    std::printf("  Without braces, a variable declared in case 1 is technically\n");
    std::printf("  'in scope' for case 2 and beyond -- even if execution jumped over it.\n");
    std::printf("  Adding {} around a case body isolates its variables.\n\n");
    int val = 2;
    switch (val) {
        case 1: {
            int result = 100;
            std::printf("  case 1: result = %d\n", result);
            break;
        }
        case 2:
            // result from case 1 is NOT accessible here (braces isolated it)
            std::printf("  case 2: reached without jumping over any initialization.\n");
            break;
    }
    std::printf("\n");

    // ---- 5. do-while: body runs at least once ---------------------------
    std::printf("  --- 5. do-while ---\n");
    int counter = 100;
    do {
        std::printf("  do-while body ran -- counter = %d\n", counter);
        counter++;
    } while (counter < 5);
    std::printf("  The condition (counter < 5) was false from the start,\n");
    std::printf("  but the body ran once anyway.\n\n");

    std::printf("  Open main.cpp and find the scope bug.\n\n");
    return 0;
}
