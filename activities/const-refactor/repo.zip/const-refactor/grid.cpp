#include "grid.hpp"

// Returns the character at (row, col).
char cell_at(char* grid, int cols, int row, int col) {
    return grid[row * cols + col];
}

// Returns true if the character at (row, col) equals target.
bool cell_is(char* grid, int cols, int row, int col, char& target) {
    return grid[row * cols + col] == target;
}

// Returns the number of cells equal to target.
int count_cells(char* grid, int rows, int cols, char& target) {
    int n = 0;
    for (int i = 0; i < rows * cols; ++i) {
        if (grid[i] == target) ++n;
    }
    return n;
}

// Returns true if a and b have identical contents.
bool grids_equal(char* a, char* b, int rows, int cols) {
    for (int i = 0; i < rows * cols; ++i) {
        if (a[i] != b[i]) return false;
    }
    return true;
}

// Returns true if any cell in the given row equals target.
bool row_contains(char* grid, int cols, int row, char& target) {
    char* r = grid + row * cols;
    for (int c = 0; c < cols; ++c) {
        if (r[c] == target) return true;
    }
    return false;
}

// Returns the column index of the first cell in row equal to target, or -1.
int find_in_row(char* grid, int cols, int row, char& target) {
    char* r = grid + row * cols;
    for (int c = 0; c < cols; ++c) {
        if (r[c] == target) return c;
    }
    return -1;
}

// Returns a pointer to the start of the given row.
char* row_ptr(char* grid, int cols, int row) {
    return grid + row * cols;
}

// Returns a mutable pointer to the start of the given row.
char* row_ptr_mut(char* grid, int cols, int row) {
    return grid + row * cols;
}

// Sets the cell at (row, col) to val.
void set_cell(char* grid, int cols, int row, int col, char val) {
    grid[row * cols + col] = val;
}

// Fills every cell with fill.
void fill_grid(char* grid, int rows, int cols, char& fill) {
    for (int i = 0; i < rows * cols; ++i) {
        grid[i] = fill;
    }
}

// Fills every cell in the given row with fill.
void fill_row(char* grid, int cols, int row, char& fill) {
    char* r = grid + row * cols;
    for (int c = 0; c < cols; ++c) {
        r[c] = fill;
    }
}

// Copies one row from src into dst (dst must have space for cols chars).
void copy_row(char* src, int src_cols, int row, char* dst) {
    char* r = src + row * src_cols;
    for (int c = 0; c < src_cols; ++c) {
        dst[c] = r[c];
    }
}

// Copies all cells from src into dst (same dimensions).
void copy_grid(char* src, char* dst, int rows, int cols) {
    for (int i = 0; i < rows * cols; ++i) {
        dst[i] = src[i];
    }
}
