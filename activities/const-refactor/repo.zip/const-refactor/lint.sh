#!/bin/bash
# Checks grid.cpp for const coverage.
# Exits 0 when no findings remain.

FINDINGS=0

# Count 'const' in grid.cpp
CONST_COUNT=$(grep -o '\bconst\b' grid.cpp | wc -l | tr -d ' ')
REQUIRED=12

if [ "$CONST_COUNT" -lt "$REQUIRED" ]; then
    echo "lint: grid.cpp has $CONST_COUNT 'const' keywords; need at least $REQUIRED."
    FINDINGS=$((FINDINGS + 1))
fi

# Check for const_cast (forbidden)
if grep -q 'const_cast' grid.cpp; then
    echo "lint: const_cast found in grid.cpp -- fix the type, do not cast it away."
    FINDINGS=$((FINDINGS + 1))
fi

if [ "$FINDINGS" -eq 0 ]; then
    echo "lint: all checks pass."
fi

exit $FINDINGS
