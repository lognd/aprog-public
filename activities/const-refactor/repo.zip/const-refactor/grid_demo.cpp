#include <cstdio>
#include "grid.hpp"

// Validation driver -- do not modify.
// Tests all 13 grid functions with fixed inputs and prints one line per function.

int main() {
    // 3x7 grid, row-major. Row 1, col 3 is index 1*7+3 = 10 -> 'X'.
    // Row 0 col 2 is index 2 -> used for find_in_row test (col=2, target='Z').
    char g[3 * 7] = {
        '.', '.', 'Z', '.', '.', '.', '.',   // row 0: 'Z' at col 2
        '.', '.', '.', 'X', '.', '.', '.',   // row 1: 'X' at col 3
        '.', '.', '.', '.', '.', '.', '.',   // row 2: all dots
    };
    // 'X' appears once in g. We need count_cells to return 3.
    // Put two more 'X' in row 2:
    g[2 * 7 + 0] = 'X';
    g[2 * 7 + 5] = 'X';
    // Now 'X' appears at: (1,3), (2,0), (2,5) -- count = 3.

    // cell_at: row=1, col=3 -> 'X'
    char c = cell_at(g, 7, 1, 3);
    printf("cell_at: %c\n", c);

    // cell_is: row=1, col=3, target='X' -> true
    char tx = 'X';
    bool ci = cell_is(g, 7, 1, 3, tx);
    printf("cell_is: %s\n", ci ? "true" : "false");

    // count_cells: count 'X' in 3x7 -> 3
    int cnt = count_cells(g, 3, 7, tx);
    printf("count_cells: %d\n", cnt);

    // grids_equal: g vs a zero-filled grid -> false
    char h[3 * 7] = {};
    bool eq = grids_equal(g, h, 3, 7);
    printf("grids_equal: %s\n", eq ? "true" : "false");

    // row_contains: row 0 contains 'Z' -> true
    char tz = 'Z';
    bool rc = row_contains(g, 7, 0, tz);
    printf("row_contains: %s\n", rc ? "true" : "false");

    // find_in_row: 'Z' in row 0 is at col 2
    int fi = find_in_row(g, 7, 0, tz);
    printf("find_in_row: %d\n", fi);

    // row_ptr: row=1, cols=7 -> offset = 7 from g
    const char* rp = row_ptr(g, 7, 1);
    printf("row_ptr offset: %d\n", (int)(rp - g));

    // set_cell: set (2,6) to 'Q', check it
    set_cell(g, 7, 2, 6, 'Q');
    printf("set_cell: %s\n", g[2 * 7 + 6] == 'Q' ? "ok" : "fail");

    // fill_grid: fill a scratch grid with '.' and check
    char scratch[2 * 3] = {};
    char fd = '.';
    fill_grid(scratch, 2, 3, fd);
    bool fill_ok = true;
    for (int i = 0; i < 6; ++i) if (scratch[i] != '.') { fill_ok = false; break; }
    printf("fill_grid: %s\n", fill_ok ? "ok" : "fail");

    // fill_row: fill row 1 of scratch with '#' and check
    char fr = '#';
    fill_row(scratch, 3, 1, fr);
    bool frow_ok = (scratch[3] == '#' && scratch[4] == '#' && scratch[5] == '#');
    printf("fill_row: %s\n", frow_ok ? "ok" : "fail");

    // copy_row: copy row 0 of g into a buffer and verify first char
    char row_buf[7] = {};
    copy_row(g, 7, 0, row_buf);
    bool cr_ok = (row_buf[2] == 'Z');
    printf("copy_row: %s\n", cr_ok ? "ok" : "fail");

    // copy_grid: copy g into a clone and compare
    char clone[3 * 7] = {};
    copy_grid(g, clone, 3, 7);
    bool cg_ok = true;
    for (int i = 0; i < 21; ++i) if (clone[i] != g[i]) { cg_ok = false; break; }
    printf("copy_grid: %s\n", cg_ok ? "ok" : "fail");

    return 0;
}
