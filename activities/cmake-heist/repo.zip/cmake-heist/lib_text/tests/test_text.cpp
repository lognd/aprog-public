#include "lib_text/text_utils.h"

extern void check(bool, const char*);

void run_tests() {
    check(digit_count(0)     == 1, "digit_count(0)==1");
    check(digit_count(9)     == 1, "digit_count(9)==1");
    check(digit_count(10)    == 2, "digit_count(10)==2");
    check(digit_count(999)   == 3, "digit_count(999)==3");
    check(digit_count(10000) == 5, "digit_count(10000)==5");
}
