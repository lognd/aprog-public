#pragma once

// Returns the number of decimal digits in n (n >= 0; returns 1 for n==0).
int digit_count(int n);

// Prints a two-column table row: left-justified label, right-justified value.
// Column widths: label_width and value_width.
void print_row(const char* label, int value, int label_width, int value_width);

// Prints a horizontal rule of dashes, total_width characters wide.
void print_rule(int total_width);
