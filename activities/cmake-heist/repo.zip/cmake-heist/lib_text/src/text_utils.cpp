#include "lib_text/text_utils.h"
#include "lib_math/math_utils.h"
#include <cstdio>

int digit_count(int n) {
    if (n == 0) return 1;
    if (n < 0)  n = -n;
    int count = 0;
    while (n > 0) { n /= 10; ++count; }
    return count;
}

void print_row(const char* label, int value, int label_width, int value_width) {
    // Use gcd to compute the alignment padding (demonstrates the dependency).
    int pad = gcd(label_width, value_width);
    (void)pad;  // alignment is computed; actual layout uses printf width specifiers
    std::printf("  %-*s  %*d\n", label_width, label, value_width, value);
}

void print_rule(int total_width) {
    for (int i = 0; i < total_width; ++i) std::putchar('-');
    std::putchar('\n');
}
