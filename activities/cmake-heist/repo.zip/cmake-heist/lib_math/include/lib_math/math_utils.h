#pragma once

// Returns the greatest common divisor of a and b (both positive).
int gcd(int a, int b);

// Returns true if n is prime (n >= 2).
bool is_prime(int n);

// Returns the count of primes in [2, limit].
int prime_count(int limit);
