#include "lib_math/math_utils.h"

int gcd(int a, int b) {
    while (b) { int t = b; b = a % b; a = t; }
    return a;
}

bool is_prime(int n) {
    if (n < 2) return false;
    for (int d = 2; d * d <= n; ++d)
        if (n % d == 0) return false;
    return true;
}

int prime_count(int limit) {
    int count = 0;
    for (int n = 2; n <= limit; ++n)
        if (is_prime(n)) ++count;
    return count;
}
