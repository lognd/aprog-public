#include <cstdio>

static int tests_run    = 0;
static int tests_failed = 0;

void check(bool ok, const char* name) {
    ++tests_run;
    if (ok) {
        std::printf("  PASS  %s\n", name);
    } else {
        ++tests_failed;
        std::printf("  FAIL  %s\n", name);
    }
}

extern void run_tests();

int main() {
    run_tests();
    std::printf("\n  %d / %d passed\n", tests_run - tests_failed, tests_run);
    return tests_failed > 0 ? 1 : 0;
}
