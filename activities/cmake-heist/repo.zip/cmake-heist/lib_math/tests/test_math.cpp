#include "lib_math/math_utils.h"

extern void check(bool, const char*);

void run_tests() {
    check(gcd(12, 8)   == 4,    "gcd(12,8)==4");
    check(gcd(7,  3)   == 1,    "gcd(7,3)==1");
    check(gcd(100, 25) == 25,   "gcd(100,25)==25");

    check(is_prime(2)  == true,  "is_prime(2)");
    check(is_prime(17) == true,  "is_prime(17)");
    check(is_prime(1)  == false, "is_prime(1)");
    check(is_prime(9)  == false, "is_prime(9)");

    check(prime_count(10)  == 4,  "prime_count(10)==4");
    check(prime_count(100) == 25, "prime_count(100)==25");
}
