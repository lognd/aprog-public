#include "lib_math/math_utils.h"
#include "lib_text/text_utils.h"
#include <cstdio>

int main() {
    const int limits[] = {10, 50, 100, 500, 1000};
    const int n_limits = 5;
    const int lw = 22, vw = 6, total = lw + vw + 4;

    std::printf("\n  Prime counts\n");
    print_rule(total);
    for (int i = 0; i < n_limits; ++i) {
        char label[32];
        std::snprintf(label, sizeof(label), "primes up to %d", limits[i]);
        print_row(label, prime_count(limits[i]), lw, vw);
    }
    print_rule(total);
    std::printf("  gcd(48, 18) = %d\n", gcd(48, 18));
    std::printf("  digits in 10000 = %d\n", digit_count(10000));
    std::printf("\n");
    return 0;
}
