// aos_bench.cpp -- Array of Structs benchmark
// DO NOT MODIFY: this file is pre-built and included for comparison only.
//
// Each Particle struct holds ALL fields together in memory: position,
// velocity, color, mass, and a debug name. The benchmark only updates
// position (x, y, z) using velocity (vx, vy, vz) -- but every iteration
// must skip over the color, mass, and name fields to reach the next particle.
#include <chrono>
#include <cstdio>
#include <cstring>
#include <cstdlib>

static const int N     = 2'000'000;
static const int ITERS = 10;

// All fields for one particle bundled together.
// Total size: 3*4 + 3*4 + 4*4 + 4 + 16 = 60 bytes per particle.
// With alignment the compiler may round up to 60 or 64 bytes.
struct Particle {
    float x, y, z;      // 12 bytes -- position, updated every frame
    float vx, vy, vz;   // 12 bytes -- velocity, read every frame
    float r, g, b, a;   // 16 bytes -- color, never touched in this loop
    float mass;          //  4 bytes -- mass, never touched in this loop
    char  name[16];      // 16 bytes -- debug name, never touched in this loop
};

static Particle* particles;

int main() {
    particles = new Particle[N];
    for (int i = 0; i < N; ++i) {
        particles[i].x  = (float)i;
        particles[i].y  = 0.0f;
        particles[i].z  = 0.0f;
        particles[i].vx = 1.0f;
        particles[i].vy = 0.0f;
        particles[i].vz = 0.0f;
        particles[i].r  = 1.0f;
        particles[i].g  = 0.5f;
        particles[i].b  = 0.2f;
        particles[i].a  = 1.0f;
        particles[i].mass = 1.0f;
        std::snprintf(particles[i].name, 16, "p%d", i % 9999);
    }

    auto t0 = std::chrono::steady_clock::now();
    for (int iter = 0; iter < ITERS; ++iter) {
        for (int i = 0; i < N; ++i) {
            particles[i].x += particles[i].vx;
            particles[i].y += particles[i].vy;
            particles[i].z += particles[i].vz;
        }
    }
    auto t1 = std::chrono::steady_clock::now();

    long ms = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();
    std::printf("AoS  update: %ld ms  (%d particles x %d iters, struct = %zu bytes)\n",
                ms, N, ITERS, sizeof(Particle));

    // Prevent the optimizer from eliminating the loop entirely.
    volatile float sink = particles[N - 1].x;
    (void)sink;

    delete[] particles;
    return 0;
}
