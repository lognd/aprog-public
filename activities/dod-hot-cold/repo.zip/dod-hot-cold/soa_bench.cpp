// soa_bench.cpp -- Struct of Arrays benchmark
// DO NOT MODIFY: this file is pre-built and included for comparison only.
//
// Instead of one big struct per particle, this version stores each field
// in its own flat array. The position arrays (x, y, z) and velocity arrays
// (vx, vy, vz) are completely separate from the cold data (color, mass, name).
// Updating position only touches six arrays -- no cold bytes are skipped over.
#include <chrono>
#include <cstdio>
#include <cstdlib>

static const int N     = 2'000'000;
static const int ITERS = 10;

// Hot data: position and velocity -- the only fields the update loop touches.
static float* xs;
static float* ys;
static float* zs;
static float* vxs;
static float* vys;
static float* vzs;

// Cold data: color, mass, name -- allocated but never accessed during the benchmark.
static float* rs;
static float* gs;
static float* bs;
static float* as_;
static float* masses;
static char*  names;

int main() {
    xs     = new float[N];
    ys     = new float[N];
    zs     = new float[N];
    vxs    = new float[N];
    vys    = new float[N];
    vzs    = new float[N];
    rs     = new float[N];
    gs     = new float[N];
    bs     = new float[N];
    as_    = new float[N];
    masses = new float[N];
    names  = new char[N * 16];

    for (int i = 0; i < N; ++i) {
        xs[i]  = (float)i;
        ys[i]  = 0.0f;
        zs[i]  = 0.0f;
        vxs[i] = 1.0f;
        vys[i] = 0.0f;
        vzs[i] = 0.0f;
        rs[i]  = 1.0f;
        gs[i]  = 0.5f;
        bs[i]  = 0.2f;
        as_[i] = 1.0f;
        masses[i] = 1.0f;
        std::snprintf(names + i * 16, 16, "p%d", i % 9999);
    }

    auto t0 = std::chrono::steady_clock::now();
    for (int iter = 0; iter < ITERS; ++iter) {
        for (int i = 0; i < N; ++i) {
            xs[i] += vxs[i];
            ys[i] += vys[i];
            zs[i] += vzs[i];
        }
    }
    auto t1 = std::chrono::steady_clock::now();

    long ms = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();
    std::printf("SoA  update: %ld ms  (%d particles x %d iters)\n", ms, N, ITERS);

    // Prevent the optimizer from eliminating the loop entirely.
    volatile float sink = xs[N - 1];
    (void)sink;

    delete[] xs; delete[] ys; delete[] zs;
    delete[] vxs; delete[] vys; delete[] vzs;
    delete[] rs; delete[] gs; delete[] bs; delete[] as_;
    delete[] masses; delete[] names;
    return 0;
}
