// rewrite_me.cpp -- Your turn to convert AoS to SoA.
//
// WHAT TO DO:
//   This file will not compile until you rewrite it.
//   Replace the AoS struct-and-array code below with a Struct of Arrays (SoA)
//   layout that produces the same result.
//
// AoS (what is here now, does not compile):
//   struct Vec2 { int x; int y; };
//   Vec2 points[1000];
//   for (int i = 0; i < 1000; ++i) { points[i].x = i; points[i].y = 0; }
//
// SoA (what you must write instead):
//   int xs[1000];
//   int ys[1000];
//   for (int i = 0; i < 1000; ++i) { xs[i] = i; ys[i] = 0; }
//
// RULES:
//   1. Declare xs[1000] and ys[1000] as separate arrays -- no struct.
//   2. Initialize: xs[i] = i, ys[i] = 0.
//   3. Sum all x values and print:   printf("sum_x: %d\n", sum_x);
//   4. The output must be exactly:   sum_x: 499500
//      (because 0+1+2+...+999 = 499500)
//
// HOW TO BUILD AND RUN:
//   make rewrite_me
//   ./rewrite_me
//
// The launcher will run ./rewrite_me automatically when you exit the shell.
// If the output matches exactly, the passphrase is revealed.
//
#include <cstdio>

// This line prevents the file from compiling until you start your rewrite.
// Delete it, then write your SoA code below.
static_assert(sizeof(char) == 0, "Delete this line and write your SoA rewrite below.");

int main() {
    // TODO: Replace this entire main() body with SoA code.
    // Step 1: declare int xs[1000]; and int ys[1000];
    // Step 2: initialize xs[i] = i; ys[i] = 0;
    // Step 3: sum all xs[i] values into an int called sum_x
    // Step 4: printf("sum_x: %d\n", sum_x);
    return 0;
}
